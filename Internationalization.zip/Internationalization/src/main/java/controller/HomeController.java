package controller;

import java.util.Locale;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import model.Customer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.context.MessageSource;


@Controller
public class HomeController {
	@Autowired
	MessageSource messageSource;
	
	@Autowired
	LocaleResolver  localeResolver;
	
	@RequestMapping(value = "/getdetails", method = RequestMethod.GET)
	public String home(@ModelAttribute("customer") Customer obj) {
	
		return "home";
	}
	

}
