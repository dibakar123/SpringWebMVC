package com.service;

import org.springframework.stereotype.Service;

import com.model.Ticket;;

@Service
public class TicketService {
	
	
	public double calculateTotalCost(Ticket ticket)
	{ double totalCost=0;
		if(ticket.getCircleType().equals("King")) {
			totalCost = (ticket.getNoOfTickets())*150;
			
		}
		if(ticket.getCircleType().equals("Queen")) {
			totalCost = (ticket.getNoOfTickets())*250;
			
		}
		return totalCost;
		
	}

}
	 	  	    	    	     	      	 	

