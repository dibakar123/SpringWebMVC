package com.example.demo;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class MovieTicketBookingApplicationTests {

	@Test
	public void contextLoads() {
	}

}
