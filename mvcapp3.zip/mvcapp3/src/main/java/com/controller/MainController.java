package com.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.model.Login;
import com.model.User;
import com.service.UserService;

@Controller
public class MainController {
  @Autowired
  public UserService userService;

  @RequestMapping(value = "/register", method = RequestMethod.GET)
  public ModelAndView showRegister(HttpServletRequest request, HttpServletResponse response) {
	//public ModelAndView showRegister() {
    ModelAndView mav = new ModelAndView("register");
    mav.addObject("user", new User());
    return mav;
  }

  @RequestMapping(value = "/registerProcess", method = RequestMethod.POST)
  public ModelAndView addUser(HttpServletRequest request, HttpServletResponse response,  @ModelAttribute("user") User user) {
    userService.register(user);
  //  return new ModelAndView("welcome", "firstname", user.getFirstname());
    ModelAndView mav = new ModelAndView("login");
    mav.addObject("login", new Login());
    return mav;
  }
  
  @RequestMapping(value = "/login", method = RequestMethod.GET)
  public ModelAndView showLogin(HttpServletRequest request, HttpServletResponse response) {
    ModelAndView mav = new ModelAndView("login");
    mav.addObject("login", new Login());
    return mav;
  }

  @RequestMapping(value = "/loginProcess", method = RequestMethod.POST)
  public ModelAndView loginProcess(HttpServletRequest request, HttpServletResponse response,   @ModelAttribute("login") Login login) {
    ModelAndView mav = null;
    User user = userService.validateUser(login);
    if (user != null) {
      mav = new ModelAndView("welcome");
      mav.addObject("firstname", user.getFirstname());
      //session manage
      HttpSession session= request.getSession();
      session.setAttribute("userid", login.getUsername());
    } else {
      mav = new ModelAndView("login");
      mav.addObject("message", "Username or Password is wrong!!");
    }
    return mav;
  }

//Form handling with Model object
@RequestMapping(value = "/contact", method = RequestMethod.POST)
public ModelAndView addContact(HttpServletRequest request, HttpServletResponse response) {
	 String name= request.getParameter("name");
	 String info = request.getParameter("info");
	 System.out.println(name+"  "+info);
	 // do some job using service layer
	 ModelAndView mav = new ModelAndView("viewcontact");
     mav.addObject("name", name.toUpperCase());
     mav.addObject("info", info.toLowerCase());
     return mav;  
     //return "viewcontact";
 }

@RequestMapping(value = "/logout", method = RequestMethod.GET)
public ModelAndView userlogout(HttpServletRequest request, HttpServletResponse response) {
	 HttpSession session =request.getSession(false);
	 session.invalidate();
	 ModelAndView mav = new ModelAndView("login");
	 mav.addObject("login", new Login());
	 return mav;
 }

@RequestMapping(value = "/viewusers", method = RequestMethod.GET)
public ModelAndView viewflight(HttpServletRequest request, HttpServletResponse response) {
	List<User>  userlist = userService.getUsers();
	 ModelAndView mav = new ModelAndView("viewusers");
	 mav.addObject("userlist", userlist);
	 HttpSession session =request.getSession(false);
	 session.setAttribute("ulist", userlist);
	 return mav;
 }



}
