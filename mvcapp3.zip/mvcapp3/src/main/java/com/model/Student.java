package com.model;

/*create table students (
id varchar(20) not null primary key,
name varchar(20),
grade varchar(20)
);*/
public class Student {
private String id;
private String name;
private String grade;

public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getGrade() {
	return grade;
}
public void setGrade(String grade) {
	this.grade = grade;
}
public String toString(){
	return "\nStudent Id : " + this.id+"\nStudent Name : " + this.name+"\nStudent Grade : " + this.grade;
}
}
