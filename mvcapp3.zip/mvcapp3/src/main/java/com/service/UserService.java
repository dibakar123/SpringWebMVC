package com.service;

import java.util.List;

import com.model.Login;
import com.model.User;

public interface UserService {

  void register(User user);

  User validateUser(Login login);
  
  public List<User> getUsers();
}
