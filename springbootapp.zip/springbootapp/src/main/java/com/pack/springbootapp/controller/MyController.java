package com.pack.springbootapp.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.pack.springbootapp.model.Users;
import com.pack.springbootapp.service.UserService;

@Controller
public class MyController {

	
	
	
	@RequestMapping(path="/login" , method=RequestMethod.GET)
	public String getLogins() {
		return "login";
	}
	
/*	@RequestMapping(path="/login" , method=RequestMethod.POST)
	public String postLogins( HttpServletRequest request , HttpServletResponse response) {
		String uid = request.getParameter("uid");
		String pwd=request.getParameter("pwd");
		if(uid.equals("abc") && pwd.equals("123"))
		       return "success";
		else
			   return "login";
	}
	*/
	
/*	@RequestMapping(path="/login" , method=RequestMethod.POST)
	public ModelAndView postLogins( HttpServletRequest request , HttpServletResponse response) {
		String uid = request.getParameter("uid");
		String pwd=request.getParameter("pwd");
		if(uid.equals("abc") && pwd.equals("123")) {
		       ModelAndView  mav = new ModelAndView("success");
		       mav.addObject("uid",uid);
		       return mav;
		}
		else {
			ModelAndView mav = new ModelAndView("login");
			mav.addObject("status","Sorry! tray againnn.....");
			return mav;
		}
	}*/
	
	@Autowired
	UserService userservice;
	
	
	@RequestMapping(path="/login" , method=RequestMethod.POST)
	public ModelAndView postLogins( @ModelAttribute Users user) {
	boolean flag = userservice.login(user);
		if(flag) {
		       ModelAndView  mav = new ModelAndView("success");
		       mav.addObject("uid",user.getUid());
		       return mav;
		}
		else {
			ModelAndView mav = new ModelAndView("login");
			mav.addObject("status","Sorry! tray againnn.....");
			return mav;
		}
	}
	
}














