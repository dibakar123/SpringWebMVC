package com.pack.springbootapp.dao;

import com.pack.springbootapp.model.Users;

public interface UserDao {
     public boolean login(Users user);
}
