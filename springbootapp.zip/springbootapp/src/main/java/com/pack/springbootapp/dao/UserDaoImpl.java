package com.pack.springbootapp.dao;
//any question????

import org.springframework.stereotype.Repository;

import com.pack.springbootapp.model.Users;

@Repository
public class UserDaoImpl implements UserDao {

	@Override
	public boolean login(Users user) {
		String uid = user.getUid();
		String pwd=user.getPwd();
		// jdbc code to check with table data
		if(uid.equals("ABC") && pwd.equals("123"))  
			return true;
		else
			return false;
	}

}
