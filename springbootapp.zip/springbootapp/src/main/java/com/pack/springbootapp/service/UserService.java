package com.pack.springbootapp.service;

import com.pack.springbootapp.model.Users;

public interface UserService {
	 public boolean login(Users user);
}
