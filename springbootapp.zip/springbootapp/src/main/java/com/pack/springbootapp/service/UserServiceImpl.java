package com.pack.springbootapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.springbootapp.dao.UserDao;
import com.pack.springbootapp.model.Users;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao userdao;
	
	@Override
	public boolean login(Users user) {
		//any kind of business logic
		String uid = user.getUid().toUpperCase();
		user.setUid(uid);
		String pwd = user.getPwd().toLowerCase();
		user.setPwd(pwd);
		return userdao.login(user);
	}

}
