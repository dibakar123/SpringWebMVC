package com.pack.springbootapp2.service;

import com.pack.springbootapp2.model.Booking;

public interface BookingService {
    public boolean makeBooking(Booking booking);
}
