package com.pack.springbootapp3.controller;


import java.util.regex.Pattern;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.pack.springbootapp3.model.Cust;

@Component
public class CustValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		return Cust.class.equals(clazz);
	}

	@Override
	public void validate(Object object, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "name.required", "Name is required.....");
		
		String pattern = "";
		Cust cust = (Cust)object;
		
	    if ((cust.getName().matches("^[A-Za-z ]{3,16}$")) ==false) {
	    	errors.rejectValue("name","cust.name.invalid", "Name should contain 3 to 16 chars only");
	    }

		
	}
	

}
