package com.pack.springbootapp3.controller;

import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pack.springbootapp3.model.Cust;
import com.pack.springbootapp3.model.Customer;

@Controller
public class HomeController {

	List<String> locationlist = Arrays.asList(new String[]{"Kolkata","Mumbai","Others"});
	
	@RequestMapping(path="/custregister" , method=RequestMethod.GET)
	public String getCustRegister(Model model) {
		model.addAttribute("customer", new Customer());
		model.addAttribute("locationlist", locationlist);
		return "register";
	}
	
	@RequestMapping(path="/custregister" , method=RequestMethod.POST)
	public String postCustRegister(   @ModelAttribute @Valid  Customer customer, BindingResult errors, Model model) {
		System.out.println(errors.hasErrors());
		if(errors.hasErrors()) {
			model.addAttribute("locationlist", locationlist);
			return "register";
		}
		
		return "success";
		
	}
	
	
	
}




